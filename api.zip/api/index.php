<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // Be cautious with '*' in production environments
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

require_once 'db_connect.php'; // Ensure this file correctly connects to your database

$response = array();

// Obtener el año desde los parámetros GET, por defecto el año actual
$ano = isset($_GET['ano']) ? intval($_GET['ano']) : date('Y');

// Validar que el año sea válido
if ($ano < 2000 || $ano > 2050) {
    $ano = date('Y');
}

// QUERY PARA EL RESUMEN POR CLIENTE (como antes)
$queryResumen = "SELECT
    T0.fc_descripcion AS CLIENTE,
    T0.fc_codigo AS CODIGO,
    YEAR(T1.b) AS AÑO,
    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"TOTAL CXC DÓLARES\",

    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN T1.b >= CURDATE() AND T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"NO VENCIDO DÓLARES\",

    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 1 AND 5 AND T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"VENCIDO 1-5 DIAS DÓLARES\",

    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 6 AND 15 AND T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"VENCIDO 6-15 DIAS DÓLARES\",

    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 16 AND 30 AND T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"VENCIDO 16-30 DIAS DÓLARES\",

    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 31 AND 60 AND T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"VENCIDO 31-60 DIAS DÓLARES\",

    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN DATEDIFF(CURDATE(), T1.b) > 60 AND T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"VENCIDO >60 DIAS DÓLARES\",

    COALESCE(FORMAT(AVG(CASE WHEN T1.tasa > 0 THEN T1.tasa END), 4), '0.0000') AS \"TASA PROMEDIO\",

    CASE
        WHEN SUM(CASE WHEN DATEDIFF(CURDATE(), T1.b) > 0 AND T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END) > 0
        THEN 'VENCIDO'
        ELSE 'AL DIA'
    END AS STATUS

FROM `etl_clientes` T0
LEFT JOIN `etl_cxc` T1 ON T0.fc_codigo = T1.rif
WHERE T1.monto_fact IS NOT NULL
  AND T1.monto_fact > 0
  AND YEAR(T1.b) = ?
GROUP BY T0.fc_descripcion, T0.fc_codigo, YEAR(T1.b)
HAVING SUM(CASE WHEN T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END) > 0

UNION ALL

SELECT
    'TOTALES' AS CLIENTE,
    '' AS CODIGO,
    ? AS AÑO,
    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"TOTAL CXC DÓLARES\",

    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN T1.b >= CURDATE() AND T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"NO VENCIDO DÓLARES\",

    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 1 AND 5 AND T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"VENCIDO 1-5 DIAS DÓLARES\",

    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 6 AND 15 AND T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"VENCIDO 6-15 DIAS DÓLARES\",

    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 16 AND 30 AND T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"VENCIDO 16-30 DIAS DÓLARES\",

    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 31 AND 60 AND T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"VENCIDO 31-60 DIAS DÓLARES\",

    COALESCE(CONCAT('$', FORMAT(SUM(
        CASE WHEN DATEDIFF(CURDATE(), T1.b) > 60 AND T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END
    ), 2)), '$0.00') AS \"VENCIDO >60 DIAS DÓLARES\",

    COALESCE(FORMAT(AVG(CASE WHEN T1.tasa > 0 THEN T1.tasa END), 4), '0.0000') AS \"TASA PROMEDIO\",

    'RESUMEN' AS STATUS

FROM `etl_cxc` T1
WHERE T1.monto_fact IS NOT NULL
  AND T1.monto_fact > 0
  AND T1.tasa > 0
  AND YEAR(T1.b) = ?";

// QUERY PARA EL DETALLE DE FACTURAS POR CLIENTE
$queryDetalle = "SELECT
    T0.fc_codigo AS CODIGO_CLIENTE,
    T0.fc_descripcion AS CLIENTE,
    T1.factura AS NUMERO_FACTURA,
    DATE_FORMAT(T1.fecha_emision, '%d/%m/%Y') AS FECHA_EMISION,
    DATE_FORMAT(T1.b, '%d/%m/%Y') AS FECHA_VENCIMIENTO,
    CONCAT('Bs. ', FORMAT(T1.monto_fact, 2)) AS MONTO_LOCAL,
    FORMAT(T1.tasa, 4) AS TASA_DIA,
    CONCAT('$', FORMAT(CASE WHEN T1.tasa > 0 THEN T1.monto_fact / T1.tasa ELSE 0 END, 2)) AS MONTO_USD,
    DATEDIFF(CURDATE(), T1.b) AS DIAS_TRANSCURRIDOS,
    CASE
        WHEN T1.b >= CURDATE() THEN 'AL DIA'
        WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 1 AND 5 THEN 'VENCIDO 1-5 DÍAS'
        WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 6 AND 15 THEN 'VENCIDO 6-15 DÍAS'
        WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 16 AND 30 THEN 'VENCIDO 16-30 DÍAS'
        WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 31 AND 60 THEN 'VENCIDO 31-60 DÍAS'
        WHEN DATEDIFF(CURDATE(), T1.b) > 60 THEN 'VENCIDO +60 DÍAS'
        ELSE 'N/A'
    END AS ESTADO_FACTURA,
    CASE
        WHEN T1.b >= CURDATE() THEN 'success'
        WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 1 AND 15 THEN 'warning'
        WHEN DATEDIFF(CURDATE(), T1.b) BETWEEN 16 AND 60 THEN 'danger'
        WHEN DATEDIFF(CURDATE(), T1.b) > 60 THEN 'contrast'
        ELSE 'secondary'
    END AS SEVERITY
FROM `etl_clientes` T0
INNER JOIN `etl_cxc` T1 ON T0.fc_codigo = T1.rif
WHERE T1.monto_fact IS NOT NULL
  AND T1.monto_fact > 0
  AND T1.tasa > 0
  AND YEAR(T1.b) = ?
ORDER BY T0.fc_descripcion, T1.b DESC";

// Ejecutar consulta de resumen
$stmtResumen = mysqli_prepare($enlace_local, $queryResumen);
if (!$stmtResumen) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al preparar consulta resumen: ' . mysqli_error($enlace_local)]);
    mysqli_close($enlace_local);
    exit();
}

mysqli_stmt_bind_param($stmtResumen, "iii", $ano, $ano, $ano);
if (!mysqli_stmt_execute($stmtResumen)) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al ejecutar consulta resumen: ' . mysqli_stmt_error($stmtResumen)]);
    mysqli_stmt_close($stmtResumen);
    mysqli_close($enlace_local);
    exit();
}

$resultResumen = mysqli_stmt_get_result($stmtResumen);
$dataResumen = [];

if (mysqli_num_rows($resultResumen) > 0) {
    while ($row = mysqli_fetch_assoc($resultResumen)) {
        $dataResumen[] = $row;
    }
}

// Ejecutar consulta de detalle
$stmtDetalle = mysqli_prepare($enlace_local, $queryDetalle);
if (!$stmtDetalle) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al preparar consulta detalle: ' . mysqli_error($enlace_local)]);
    mysqli_stmt_close($stmtResumen);
    mysqli_close($enlace_local);
    exit();
}

mysqli_stmt_bind_param($stmtDetalle, "i", $ano);
if (!mysqli_stmt_execute($stmtDetalle)) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al ejecutar consulta detalle: ' . mysqli_stmt_error($stmtDetalle)]);
    mysqli_stmt_close($stmtResumen);
    mysqli_stmt_close($stmtDetalle);
    mysqli_close($enlace_local);
    exit();
}

$resultDetalle = mysqli_stmt_get_result($stmtDetalle);
$dataDetalle = [];

if (mysqli_num_rows($resultDetalle) > 0) {
    while ($row = mysqli_fetch_assoc($resultDetalle)) {
        $codigoCliente = $row['CODIGO_CLIENTE'];
        if (!isset($dataDetalle[$codigoCliente])) {
            $dataDetalle[$codigoCliente] = [];
        }
        $dataDetalle[$codigoCliente][] = $row;
    }
}

// Agregar detalles a cada cliente en el resumen
foreach ($dataResumen as &$cliente) {
    if ($cliente['CLIENTE'] !== 'TOTALES') {
        $codigo = $cliente['CODIGO'];
        $cliente['DETALLE_FACTURAS'] = isset($dataDetalle[$codigo]) ? $dataDetalle[$codigo] : [];
        $cliente['TOTAL_FACTURAS'] = count($cliente['DETALLE_FACTURAS']);
    } else {
        $cliente['DETALLE_FACTURAS'] = [];
        $cliente['TOTAL_FACTURAS'] = 0;
    }
}

// Estructurar respuesta
$response = [
    'success' => true,
    'ano_consultado' => $ano,
    'total_registros' => count($dataResumen),
    'fecha_consulta' => date('Y-m-d H:i:s'),
    'data' => $dataResumen,
    'estadisticas' => [
        'total_clientes' => count(array_filter($dataResumen, function ($item) {
            return $item['CLIENTE'] !== 'TOTALES';
        })),
        'total_facturas' => count($dataDetalle) > 0 ? array_sum(array_map('count', $dataDetalle)) : 0
    ]
];

echo json_encode($response);

mysqli_stmt_close($stmtResumen);
mysqli_stmt_close($stmtDetalle);
mysqli_close($enlace_local);
